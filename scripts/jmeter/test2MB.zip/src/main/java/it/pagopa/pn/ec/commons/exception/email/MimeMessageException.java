package it.pagopa.pn.ec.commons.exception.email;

public class MimeMessageException extends RuntimeException {

    public MimeMessageException(String message) {
        super(message);
    }

}
