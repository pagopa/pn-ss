package it.pagopa.pn.ec.commons.exception;

public class XmlParserException extends RuntimeException{

    public XmlParserException(String msg) {
        super(msg);
    }
}
