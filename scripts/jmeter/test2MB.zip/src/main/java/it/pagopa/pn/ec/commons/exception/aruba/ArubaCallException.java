package it.pagopa.pn.ec.commons.exception.aruba;

public class ArubaCallException extends RuntimeException {

    public ArubaCallException(String message) {
        super(message);
    }

}
