# pn-template-ms-be

A template project for a new PN backend microservice.
