package it.pagopa.pn.ec.consolidatore.exception;

public class AttachmentsEmptyRicezioneEsitiCartaceoException extends RuntimeException {

}
