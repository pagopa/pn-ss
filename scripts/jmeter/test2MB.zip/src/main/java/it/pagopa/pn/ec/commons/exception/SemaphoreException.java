package it.pagopa.pn.ec.commons.exception;

public class SemaphoreException extends RuntimeException{

    public SemaphoreException(String message) {
        super(message);
    }

}
